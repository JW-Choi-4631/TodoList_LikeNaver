import React from 'react'

function contents() {
  return (
    <div>contents</div>
  )
}

export default contents